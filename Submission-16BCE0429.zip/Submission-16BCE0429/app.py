
from flask import Flask, render_template, request, Response, jsonify
from flask import url_for,  redirect
from flask_pymongo import PyMongo
from pymongo import MongoClient
import json

from flask_cors import CORS, cross_origin
from datetime import datetime


client = MongoClient()
db = client.udaan

app = Flask(__name__)

cors = CORS(app)
app.config['MONGO_DBNAME'] = 'udaan'
app.config["MONGO_URI"] = "mongodb://localhost:27017/udaan"
mongo = PyMongo(app)

asset = db.Assets.find()
data = db.Allocated.find()


# Views
@app.route('/', methods=["GET"])
def home():
	data = db.Allocated.find()
	return render_template("index.html",data=data)

@app.route('/login', methods=['POST'])
def login():
	
    users = db.users
    login_user = users.find_one({'name' : request.form['username']})
    if login_user:
        if (request.form['pass'] == login_user['pass']):
			
            return render_template("admin.html",data=data,asset=asset)

    return 'Invalid username/password combination'


@app.route('/add_asset', methods=["POST"])
def add_asset():
	try:
		assetID=request.form.get("assetID")
		if(len(assetID)>0):
			assetis ={
				"AssetId" : assetID,
				"AssetName" : request.form.get("assetName")
			}
			assets = db.Assets
			assetid = assets.insert_one(assetis).inserted_id
			return Response(" Successful")
		else:
			return Response("ID too short",400,mimetype="application/json")	
	except:
		return Response("Incorrect way fo accessing the API. Choose the correct format. Make sure you pass through the formData or the Database in down for maintainence",400,mimetype="application/json")

@app.route('/add_task', methods=["POST"])
def add_task():
	try:
		try:
		
			assetis ={
				"Task" : request.form.get("name"),
				"Description"  : request.form.get("description")
			}
			assets = db.task
			assetid = assets.insert_one(assetis).inserted_id
		
			return Response("The task is sucessfuly added",200,mimetype="application/json")
		except:
			return Response("The taskID already exists",400,mimetype="application/json")
	
	except:
		return Response("Incorrect way fo accessing the API. Choose the correct format. Make sure you pass through the formData or the Database in down for maintainence",400,mimetype="application/json")


@app.route('/add_worker', methods=["POST"])
def add_worker():
	try:
		workerID=request.form.get("workerID")

		if(len(workerID)>0):
			
			try:
				assetis ={
				"Worker ID" : request.form.get("workerID"),
				"Name"  : request.form.get("Workername")
				}
				assets = db.users
				assetid = assets.insert_one(assetis).inserted_id
		
				return Response("The worker is sucessfuly added",200,mimetype="application/json")
			except:
				return Response("The workerID already exists",400,mimetype="application/json")
		else:
			return Response("Empty string won't be accepted",400,mimetype="application/json")	
	except:
		return Response("Incorrect way fo accessing the API. Choose the correct format. Make sure you pass through the formData or the Database in down for maintainence",400,mimetype="application/json")

@app.route('/allocate', methods=["POST"])
def allocate():
	try:
		try:
		
			assetis ={
				"Worker" : request.form.get("name"),
				"Asset"  : request.form.get("assetName"),
				"Given" : datetime.now(),
				"Deadline" : request.form.get("time"),
				"Action" : request.form.get("action")
			}
			assets = db.Allocated
			assetid = assets.insert_one(assetis).inserted_id
		
			return Response("The task is sucessfuly added",200,mimetype="application/json")
		except:
			return Response("The taskID already exists",400,mimetype="application/json")
	
	except:
		return Response("Incorrect way fo accessing the API. Choose the correct format. Make sure you pass through the formData or the Database in down for maintainence",400,mimetype="application/json")

# Run
if __name__ == '__main__':
    app.run(debug=True)
