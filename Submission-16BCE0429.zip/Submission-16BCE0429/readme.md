#Introduction
The API created for housekeeping web interface is python based. The APis are built on Flask framework which interacts with frontend, which was designed using Bootstrap. Database used here is MongoDB.
Name of Database is udaan and collections are Allocated, tasks, Assests and users. 
 
To see the demonstration, one must have python, flask, pymongo and mongodb. The database configuration must be as given above, i.e. udaan database with 3 collections.

#Dependencies to be installed
One can use following commands to install the required dependencies and configurations: 



           pip3 install Flask-PyMongo 
           sudo apt-key adv --keyserver hkp://keyserver.ubuntu.com:80 --recv EA312927  
           echo "deb http://repo.mongodb.org/apt/ubuntu xenial/mongodb-org/3.2 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-3.2.list   		   sudo apt-get update    
           sudo apt-get install -y mongodb-org
           sudo systemctl start mongod
           sudo systemctl status mongod
           python -m pip install pymongo
           systemctl enable mongod.service
           python3 -m pip install pymongo
           sudo apt install python3-flask
           flask run
           export FLASK_APP=app.py
           pip3 install -U flask-cors
#Start Apllication
	Run flask run in terminal and then open http://127.0.0.1:5000 on web browser
#Description

	Home page is common for everyone, but if anyone who wants to alter or assign duties, they need to login with admin credentials given below and do the required changes.

Username : Admin
Password: admin123

#Views

app.route('/add_asset', methods=["POST"])
	This API adds assets to the database.

app.route('/add_task', methods=["POST"])
	This API adds new taks for the particular type.

app.route('/add_worker', methods=["POST"])
	This adds workers to the database
	
app.route('/allocate', methods=["POST"])
	This allocates the work to particular worker and shows it in the form of table.
